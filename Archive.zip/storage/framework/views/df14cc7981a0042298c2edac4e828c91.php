<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-2">
        <h3>Detail Event: <?php echo e($event->name); ?></h3>

        <div class="card shadow mb-3">
            <div class="card-body">
                <p><strong>Tanggal:</strong> <?php echo e($event->event_date->format('d M Y')); ?></p>
                <p><strong>Waktu:</strong> <?php echo e($event->event_time); ?></p>
                <p><strong>Status:</strong>
                    <span
                        class="badge bg-<?php echo e($event->status == 'upcoming' ? 'primary' : ($event->status == 'ongoing' ? 'success' : 'secondary')); ?>">
                        <?php echo e(ucfirst($event->status)); ?>

                    </span>
                </p>
                <p><strong>Deskripsi:</strong> <?php echo e($event->description ?? '-'); ?></p>

                <?php if($event->event_link): ?>
                    <p>
                        <strong>Link:</strong>
                        <a href="<?php echo e($event->event_link); ?>" target="_blank">
                            <?php echo e($event->event_link); ?>

                        </a>
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col">
                    
                    <div class="card shadow mb-3">
                        <div class="card-header">
                            <strong>Barang Dipinjam</strong>
                        </div>
                        <div class="card-body p-0">
                            <?php if($event->items->count()): ?>
                                <table class="table table-bordered mb-0">
                                    <thead>
                                        <tr>
                                            <th>Barang</th>
                                            <th>Diambil</th>
                                            <th>Dikembalikan</th>
                                            <th>Sisa</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $event->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->pivot->quantity_taken); ?></td>
                                                <td><?php echo e($item->pivot->quantity_returned); ?></td>
                                                <td>
                                                    <?php echo e($item->pivot->quantity_taken - $item->pivot->quantity_returned); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p class="p-3 text-muted">Belum ada barang dipinjam.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <?php if($event->status !== 'completed' && $event->items->count()): ?>
                        <div class="card shadow mb-3">
                            <div class="card-header">
                                <strong>Kembalikan Barang</strong>
                            </div>
                            <div class="card-body p-0">
                                <table class="table table-bordered mb-0">
                                    <thead>
                                        <tr>
                                            <th>Barang</th>
                                            <th>Sisa Dipinjam</th>
                                            <th>Jumlah Kembali</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $event->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $sisa = $item->pivot->quantity_taken - $item->pivot->quantity_returned;
                                            ?>

                                            <?php if($sisa > 0): ?>
                                                <tr>
                                                    <td><?php echo e($item->name); ?></td>
                                                    <td><?php echo e($sisa); ?></td>
                                                    <td>
                                                        <form action="<?php echo e(route('event-items.update', $item->pivot->id)); ?>"
                                                            method="POST" class="d-flex gap-2">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PATCH'); ?>

                                                            <input type="number" name="quantity_returned"
                                                                class="form-control" min="1"
                                                                max="<?php echo e($sisa); ?>" required>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-success btn-sm">
                                                            Kembalikan
                                                        </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <?php if($event->status !== 'completed'): ?>
            <div class="card shadow mb-3">
                <div class="card-header">
                    <strong>Pinjam Barang</strong>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('event-items.store', $event->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-6">
                                <label>Barang</label>
                                <select name="item_id" class="form-control" required>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"
                                            <?php echo e($item->available_stock <= 0 ? 'disabled' : ''); ?>>
                                            <?php echo e($item->name); ?>

                                            (Sisa: <?php echo e($item->available_stock); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-3">
                                <label>Jumlah</label>
                                <input type="number" name="quantity_taken" class="form-control" min="1" required>
                            </div>

                            <div class="col-md-3 d-flex align-items-end">
                                <button class="btn btn-primary w-100">
                                    Pinjam
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        <a href="<?php echo e(route('events.index')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/code/event-system/resources/views/events/show.blade.php ENDPATH**/ ?>