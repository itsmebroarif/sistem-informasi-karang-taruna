<?php $__env->startSection('title', 'Uang Kas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">

    
    <div class="row g-3 mb-4">

        
        <div class="col-md-4">
            <div class="card shadow-sm border-0 bg-success bg-gradient text-white">
                <div class="card-body d-flex align-items-center">
                    <div class="me-3 fs-1 opacity-75">
                        <i class="bi bi-arrow-down-circle"></i>
                    </div>
                    <div>
                        <small class="text-uppercase">Total Masuk</small>
                        <h4 class="fw-bold mb-0">
                            Rp <?php echo e(number_format($totalMasuk, 0, ',', '.')); ?>

                        </h4>
                    </div>
                </div>
            </div>
        </div>
    
        
        <div class="col-md-4">
            <div class="card shadow-sm border-0 bg-danger bg-gradient text-white">
                <div class="card-body d-flex align-items-center">
                    <div class="me-3 fs-1 opacity-75">
                        <i class="bi bi-arrow-up-circle"></i>
                    </div>
                    <div>
                        <small class="text-uppercase">Total Keluar</small>
                        <h4 class="fw-bold mb-0">
                            Rp <?php echo e(number_format($totalKeluar, 0, ',', '.')); ?>

                        </h4>
                    </div>
                </div>
            </div>
        </div>
    
        
        <div class="col-md-4">
            <div class="card shadow-sm border-0 bg-primary bg-gradient text-white">
                <div class="card-body d-flex align-items-center">
                    <div class="me-3 fs-1 opacity-75">
                        <i class="bi bi-wallet2"></i>
                    </div>
                    <div>
                        <small class="text-uppercase">Saldo Akhir</small>
                        <h4 class="fw-bold mb-0">
                            Rp <?php echo e(number_format($saldo, 0, ',', '.')); ?>

                        </h4>
                    </div>
                </div>
            </div>
        </div>
    
    </div>
    

    
    <div class="mb-3 d-flex justify-content-between">
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambah">
            + Tambah Kas
        </button>

        <a href="<?php echo e(route('kas.export.csv')); ?>" class="btn btn-outline-primary">
            Export CSV
        </a>
    </div>

    
    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Jenis</th>
                        <th>Sumber</th>
                        <th>Jumlah</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($row->tanggal->format('d-m-Y')); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($row->jenis == 'masuk' ? 'success' : 'danger'); ?>">
                                <?php echo e(strtoupper($row->jenis)); ?>

                            </span>
                        </td>
                        <td><?php echo e($row->sumber); ?></td>
                        <td>Rp <?php echo e(number_format($row->jumlah, 0, ',', '.')); ?></td>
                        <td><?php echo e($row->keterangan); ?></td>
                        <td>
                            <form action="<?php echo e(route('kas.destroy', $row->id)); ?>" method="POST"
                                onsubmit="return confirm('Yakin hapus data ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php echo $__env->make('kas.modal-tambah', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/code/event-system/resources/views/kas/index.blade.php ENDPATH**/ ?>