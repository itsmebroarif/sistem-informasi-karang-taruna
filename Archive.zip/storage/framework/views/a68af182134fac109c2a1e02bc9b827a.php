<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">
    <h3>Buat Tim Baru</h3>

    <form action="<?php echo e(route('teams.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label">Nama Tim</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
        </div>

        <button class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan</button>
        <a href="<?php echo e(route('teams.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/code/event-system/resources/views/teams/create.blade.php ENDPATH**/ ?>