<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h3>Tambah Anggota</h3>

    <form action="<?php echo e(route('members.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Nama</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Role</label>
            <input type="text" name="role" class="form-control" value="<?php echo e(old('role')); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Phone Number</label>
            <input type="text" name="phone_number" class="form-control" value="<?php echo e(old('phone_number')); ?>" required>
        </div>
        <button class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan</button>
        <a href="<?php echo e(route('members.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/code/event-system/resources/views/members/create.blade.php ENDPATH**/ ?>