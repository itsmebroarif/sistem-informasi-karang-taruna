<?php $__env->startSection('title', 'Invoice'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="mb-3">
        <h1>Invoice System</h1>
        <p class="lead">Tolong Gunakan sistem ini untuk report pengeluaran dengan jujur</p>
        <a href="<?php echo e(route('invoice.create')); ?>" class="btn btn-primary">
            + Buat Invoice
        </a>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No Invoice</th>
                        <th>Nama</th>
                        <th>Tanggal</th>
                        <th>Total</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($inv->invoice_number); ?></td>
                        <td><?php echo e($inv->customer_name); ?></td>
                        <td><?php echo e($inv->invoice_date->format('d-m-Y')); ?></td>
                        <td>Rp <?php echo e(number_format($inv->total,0,',','.')); ?></td>
                        <td>
                            <a href="<?php echo e(route('invoice.print', $inv->id)); ?>" target="_blank"
                               class="btn btn-sm btn-success">
                                Cetak
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/code/event-system/resources/views/invoice/index.blade.php ENDPATH**/ ?>