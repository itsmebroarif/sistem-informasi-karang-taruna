<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="d-flex justify-content-between mb-3 mt-2 py-4">
        <h4 class="fw-bold display-5">Rundown Acara</h4>
        <div>
            <a href="<?php echo e(route('rundown.print')); ?>" target="_blank" class="btn btn-secondary">
                <i class="bi bi-printer"></i> Cetak PDF
            </a>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
                <i class="bi bi-plus"></i> Tambah
            </button>
        </div>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Waktu</th>
                <th>Kegiatan</th>
                <th>PJ</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row->tanggal); ?></td>
                <td><?php echo e($row->waktu_mulai); ?> - <?php echo e($row->waktu_selesai); ?></td>
                <td><?php echo e($row->kegiatan); ?></td>
                <td><?php echo e($row->penanggung_jawab); ?></td>
                <td>
                    <form action="<?php echo e(route('rundown.destroy', $row->id)); ?>" method="POST" class="delete-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm">
                            <i class="bi bi-trash"></i>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>


<div class="modal fade" id="modalTambah">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('rundown.store')); ?>" class="modal-content">
            <?php echo csrf_field(); ?>
            <div class="modal-header">
                <h5>Tambah Rundown</h5>
            </div>
            <div class="modal-body">
                <input type="date" name="tanggal" class="form-control mb-2" required>
                <input type="time" name="waktu_mulai" class="form-control mb-2" required>
                <input type="time" name="waktu_selesai" class="form-control mb-2">
                <input type="text" name="kegiatan" class="form-control mb-2" placeholder="Nama kegiatan" required>
                <input type="text" name="penanggung_jawab" class="form-control mb-2" placeholder="Penanggung jawab">
                <textarea name="keterangan" class="form-control" placeholder="Keterangan"></textarea>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/code/event-system/resources/views/rundown/index.blade.php ENDPATH**/ ?>