<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Detail Tim: <?php echo e($team->name); ?></h3>
        <a href="<?php echo e(route('teams.index')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5 class="mb-3">Anggota Tim</h5>

            <?php if($team->members->count() > 0): ?>
                <ul class="list-group mb-3">
                    <?php $__currentLoopData = $team->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <?php echo e($member->name); ?> (<?php echo e($member->role); ?>)
                            <form action="<?php echo e(route('team-members.destroy', $member->pivot->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin mengeluarkan anggota?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger"><i class="bi bi-trash me-1"></i> Keluarkan</button>
                            </form>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p class="text-muted">Belum ada anggota di tim ini.</p>
            <?php endif; ?>

            <form action="<?php echo e(route('team-members.store', $team->id)); ?>" method="POST" class="row g-2 align-items-center">
                <?php echo csrf_field(); ?>
                <div class="col-auto">
                    <select name="member_id" class="form-select" required>
                        <option value="">-- Pilih Anggota --</option>
                        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$team->members->contains($member)): ?>
                                <option value="<?php echo e($member->id); ?>"><?php echo e($member->name); ?> (<?php echo e($member->role); ?>)</option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-auto">
                    <button class="btn btn-primary"><i class="bi bi-plus me-1"></i> Tambah Anggota</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/code/event-system/resources/views/teams/show.blade.php ENDPATH**/ ?>