<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h3>Tambah Barang</h3>

    <form action="<?php echo e(route('items.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Nama Barang</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Total Quantity</label>
            <input type="number" name="total_quantity" class="form-control" value="<?php echo e(old('total_quantity')); ?>" required min="0">
        </div>
        <div class="mb-3">
            <label class="form-label">Damaged Quantity</label>
            <input type="number" name="damaged_quantity" class="form-control" value="<?php echo e(old('damaged_quantity')); ?>" min="0">
        </div>
        <div class="mb-3">
            <label class="form-label">Replacement Link</label>
            <input type="url" name="replacement_link" class="form-control" value="<?php echo e(old('replacement_link')); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Keterangan</label>
            <textarea name="description" class="form-control"><?php echo e(old('description')); ?></textarea>
        </div>
        <button class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan</button>
        <a href="<?php echo e(route('items.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/code/event-system/resources/views/items/create.blade.php ENDPATH**/ ?>