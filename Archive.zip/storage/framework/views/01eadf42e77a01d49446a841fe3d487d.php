<?php $__env->startSection('content'); ?>
<div class="app-content-header">
    <div class="container-fluid">
        <div class="row mb-3">
            <div class="col-sm-6">
                <h3 class="mb-0">Daftar Event</h3>
            </div>
            <div class="col-sm-6 text-end">
                <a href="<?php echo e(route('events.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-circle me-1"></i> Buat Event
                </a>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="card shadow">
            <div class="card-body table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama Event</th>
                            <th>Tanggal</th>
                            <th>Waktu</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($event->name); ?></td>
                            <td><?php echo e($event->event_date->format('d M Y')); ?></td>
                            <td><?php echo e($event->event_time); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($event->status=='upcoming' ? 'primary' : ($event->status=='ongoing' ? 'success' : 'secondary')); ?>">
                                    <?php echo e(ucfirst($event->status)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('events.show', $event)); ?>" class="btn btn-sm btn-info">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <a href="<?php echo e(route('events.edit', $event)); ?>" class="btn btn-sm btn-warning">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('events.destroy', $event)); ?>" method="POST" class="d-inline"
                                      onsubmit="return confirm('Yakin ingin menghapus event ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">Belum ada event</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/code/event-system/resources/views/events/index.blade.php ENDPATH**/ ?>