<?php $__env->startSection('title', 'Buat Invoice'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow-sm">
        <div class="card-header">
            <h5 class="mb-0">Form Invoice</h5>
        </div>

        <form action="<?php echo e(route('invoice.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="card-body">

                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label>Nama Penerima</label>
                        <input type="text" name="customer_name" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label>Metode Pembayaran</label>
                        <input type="text" name="payment_method" class="form-control" required>
                    </div>
                </div>

                <hr>

                
                <h6>Detail Item</h6>

                <table class="table table-bordered" id="itemsTable">
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th>Deskripsi</th>
                            <th width="80">Qty</th>
                            <th width="150">Harga</th>
                            <th width="50"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <input type="text" name="items[0][product_name]" class="form-control" required>
                            </td>
                            <td>
                                <input type="text" name="items[0][description]" class="form-control">
                            </td>
                            <td>
                                <input type="number" name="items[0][quantity]" class="form-control" required>
                            </td>
                            <td>
                                <input type="number" name="items[0][price]" class="form-control" required>
                            </td>
                            <td>
                                <button type="button" class="btn btn-danger btn-sm remove-row">✕</button>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <button type="button" class="btn btn-outline-primary btn-sm" id="addRow">
                    + Tambah Item
                </button>

            </div>

            <div class="card-footer text-end">
                <button class="btn btn-success">
                    Simpan & Cetak Invoice
                </button>
            </div>
        </form>
    </div>
</div>


<script>
let index = 1;

document.getElementById('addRow').addEventListener('click', function () {
    const table = document.querySelector('#itemsTable tbody');
    table.insertAdjacentHTML('beforeend', `
        <tr>
            <td><input type="text" name="items[${index}][product_name]" class="form-control" required></td>
            <td><input type="text" name="items[${index}][description]" class="form-control"></td>
            <td><input type="number" name="items[${index}][quantity]" class="form-control" required></td>
            <td><input type="number" name="items[${index}][price]" class="form-control" required></td>
            <td><button type="button" class="btn btn-danger btn-sm remove-row">✕</button></td>
        </tr>
    `);
    index++;
});

document.addEventListener('click', function(e){
    if(e.target.classList.contains('remove-row')){
        e.target.closest('tr').remove();
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/code/event-system/resources/views/invoice/create.blade.php ENDPATH**/ ?>