<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: DejaVu Sans; font-size: 12px; }
        table { width:100%; border-collapse: collapse; }
        th,td { border:1px solid #000; padding:6px; }
        th { background:#eee; }
    </style>
</head>
<body>

<h3 style="text-align:center">RUNDOWN ACARA KARANG TARUNA</h3>

<table>
    <thead>
        <tr>
            <th>Tanggal</th>
            <th>Waktu</th>
            <th>Kegiatan</th>
            <th>PJ</th>
            <th>Keterangan</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($row->tanggal); ?></td>
            <td><?php echo e($row->waktu_mulai); ?> - <?php echo e($row->waktu_selesai); ?></td>
            <td><?php echo e($row->kegiatan); ?></td>
            <td><?php echo e($row->penanggung_jawab); ?></td>
            <td><?php echo e($row->keterangan); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/code/event-system/resources/views/rundown/print.blade.php ENDPATH**/ ?>