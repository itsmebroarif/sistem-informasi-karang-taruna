<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
        <a href="<?php echo e(url('/')); ?>" class="brand-link">
            <img src="<?php echo e(asset('images\icons\laravel.svg')); ?>" alt="Logo" class="brand-image img-circle elevation-3"
                style="opacity: .8">
            <span class="brand-text fw-dark">SISKATAR</span>
        </a>
    </div>
    <div class="sidebar-wrapper">
        <nav class="mt-2">
            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" data-accordion="false">

                
                <li class="nav-item">
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                        <i class="nav-icon bi bi-speedometer"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                
                <li class="nav-item <?php echo e(request()->routeIs('events.*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link <?php echo e(request()->routeIs('events.*') ? 'active' : ''); ?>">
                        <i class="nav-icon bi bi-calendar-event"></i>
                        <p>
                            Event
                            <i class="nav-arrow bi bi-chevron-right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('events.index')); ?>"
                                class="nav-link <?php echo e(request()->routeIs('events.index') ? 'active' : ''); ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p>Daftar Event</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('events.create')); ?>"
                                class="nav-link <?php echo e(request()->routeIs('events.create') ? 'active' : ''); ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p>Buat Event</p>
                            </a>
                        </li>
                    </ul>
                </li>

                
                <li class="nav-item">
                    <a href="<?php echo e(route('items.index')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('items.index') ? 'active' : ''); ?>">
                        <i class="nav-icon bi bi-box-seam"></i>
                        <p>Barang</p>
                    </a>
                </li>

                
                <li class="nav-item">
                    <a href="<?php echo e(route('members.index')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('members.index') ? 'active' : ''); ?>">
                        <i class="nav-icon bi bi-people"></i>
                        <p>Anggota</p>
                    </a>
                </li>

                
                <li class="nav-item <?php echo e(request()->routeIs('teams.index') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link <?php echo e(request()->routeIs('teams.index') ? 'active' : ''); ?>">
                        <i class="nav-icon bi bi-diagram-3"></i>
                        <p>
                            Tim
                            <i class="nav-arrow bi bi-chevron-right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('teams.index')); ?>"
                                class="nav-link <?php echo e(request()->routeIs('teams.index') ? 'active' : ''); ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p>Daftar Tim</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('teams.create')); ?>"
                                class="nav-link <?php echo e(request()->routeIs('teams.create') ? 'active' : ''); ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p>Buat Tim</p>
                            </a>
                        </li>
                    </ul>
                </li>

                
                <li class="nav-item">
                    <a href="<?php echo e(route('kas.index')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('kas.*') ? 'active' : ''); ?>">
                        <i class="nav-icon bi bi-cash-stack"></i>
                        <p>Uang Kas</p>
                    </a>
                </li>

                
                <li class="nav-item">
                    <a href="<?php echo e(route('invoice.index')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('invoice.*') ? 'active' : ''); ?>">
                        <i class="nav-icon bi bi-receipt"></i>
                        <p>Invoice</p>
                    </a>
                </li>

                
                <li class="nav-item">
                    <a href="<?php echo e(route('rundown.index')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('rundown.*') ? 'active' : ''); ?>">
                        <i class="nav-icon bi bi-list-check"></i>
                        <p>Rundown Acara</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/code/event-system/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>